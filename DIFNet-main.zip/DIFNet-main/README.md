# DIFNet
we proposes a data-driven method, termed Decentralized Information Fusion Neural Network (Decentralized IFNet), to learn unknown noise correlations in data for discrete-time nonlinear state space models with cross-correlated measurement noises.
