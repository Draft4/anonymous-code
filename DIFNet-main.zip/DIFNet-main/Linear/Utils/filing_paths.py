path_model_Lor = '../../Simulations/Lorenz_Attractor/'
path_model_NCLT = 'Simulations/NCLT/'
path_model_Toy = 'Simulations/Toy_problems/'
path_model_Pendulum = '../../Simulations/Pendulum/'

path_model = path_model_Lor
